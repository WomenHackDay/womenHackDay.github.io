n = int(raw_input())
for i in range(n):
    a = raw_input()
    b = raw_input()
    c, d = (a, b) if len(a) < len(b) else (b, a)
    ok = 1
    t = []
    for e in c:
        if e in t:
            continue
        else:
           t.append(e)
        if e in d:
            print "YES"
            ok = 0
            break
    if ok == 1:
        print "NO"
