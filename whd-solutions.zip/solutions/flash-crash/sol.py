n = int(raw_input())
vs = [ int(i) for i in raw_input().split() ]

d = 0
s = 0
for i in range(len(vs)-1):
    s += vs[i] - vs[i+1]
    if s < 0:
        s = 0
    if s > d:
        d = s
if d > 0:
    print -d
else:
    print 0
