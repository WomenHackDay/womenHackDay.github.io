raw_input()
tab = raw_input().strip().split()
tab.sort(key=float)
print " ".join(tab)
