for i in range(int(raw_input())):
    ok = 1
    e = raw_input()
    l = len(e)
    for k in range(l/2):
        if e[k] != e[l-k-1]:
            ok = 0
            break
    if ok: 
        print -1
        continue
    for j in range(len(e)):
        w = e[0:j] + e[j+1:]
        a = len(w)/2
        b = a if len(w) % 2 == 0 else a+1
        if w[:a][::-1] == w[b:]:
            ok = 0
            print j
            break
