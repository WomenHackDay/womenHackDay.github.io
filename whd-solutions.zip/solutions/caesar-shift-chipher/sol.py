raw_input()
d = raw_input().strip().split()
c = raw_input().strip().split()
for k in range(26):
  s = ""
  for e in c[0]:
    s += chr(((ord(e) - 65 + k) % 26) + 65)
  if s in d:
    break

p = ""
for j in range(len(c)):
    for e in c[j]:
      p += chr(((ord(e) - 65 + k) % 26) + 65)
    p += " "

print p.strip()
