r = int(raw_input())
l = int(raw_input())

d = []
d.append(str(r))

for i in range(1,l):
    line = d[i-1].split()
    index = 0
    k = line[0]
    nums = []
    chars = []
    nums.append(1)
    chars.append(k)
    for i in range(1, len(line)):
        if k == line[i]:
            nums[index] += 1
        else:
            index += 1
            k = line[i]
            chars.append(k)
            nums.append(1)
    data = ""
    for i in range(len(nums)):
        data += str(nums[i]) + " " + chars[i] + " "
    d.append(data)

print d[l-1].strip()
