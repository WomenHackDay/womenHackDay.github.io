n = int(raw_input())
pi = []
for i in xrange(n):
    pi.append(int(raw_input()))

pi.sort()
D = 10000000
for i in range(len(pi)-1):
    d = abs(pi[i] - pi[i+1])
    if d < D:
        D = d
print D
