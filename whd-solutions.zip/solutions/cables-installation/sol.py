n = int(raw_input())
mp = {}
build = []
m1 = 2**30 + 1
m2 = -2**30 - 1
for i in xrange(n):
    t = [int(j) for j in raw_input().split()]
    build.append(t)
    if t[0] > m2:
        m2 = t[0]
    if t[0] < m1:
        m1 = t[0]
    if mp.has_key(t[1]):
        mp[t[1]] += 1
    else:
        mp[t[1]] = 1
mx = 0
index = 0
for k in mp.keys():
    if mp[k] > mx:
        mx = mp[k]
        index = k
s = 0
num = 0
for k in mp.keys():
    if mp[k] == mx:
        num += 1
        s += k
if num > 1:
    index = s / 2

l = 0
for e in build:
    l += abs(e[1] - index)
print l + abs(m2 - m1)
