import sys

n, l = map(int, raw_input().split())
g = [[[]] for _ in range(n)]
w = [1 for _ in range(n)]
for i in range(l):
  a, b = map(int, raw_input().split())
  g[a-1][0].append(b)
  g[b-1][0].append(a)
  w[a-1] += 1
  if w[a-1] == n:
      print a
      sys.exit(0)
  w[b-1] += 1
  if w[b-1] == n:
      print b
      sys.exit(0)

k = True
p = 0
while k:
  for i in range(n):
    tmp = []
    for e in g[i][p]:
      for ee in g[e-1][0]:
        ok = True
        for x in g[i]:
          if ee in x:
            ok = False
            break
        if ee-1 != i and ok and ee not in tmp: tmp.append(ee)
    if tmp:
      g[i].append(tmp)
      w[i] += len(tmp)
      if w[i] == n:
        k=False
        break
  p+=1

print i+1
