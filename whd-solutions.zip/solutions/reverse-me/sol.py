for i in range(int(raw_input())): 
  print raw_input().strip()[::-1]
